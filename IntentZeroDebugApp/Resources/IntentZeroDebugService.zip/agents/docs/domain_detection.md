# 도메인 자동 감지 & 템플릿 선택

목표: 사용자가 아이디어 한 줄을 입력하면, 적절한 질문 팩과 명세 템플릿을 자동으로 선택한다.

## 데이터 구성
- `SpecAgent/domain_catalog.json`
  ```json
  {
    "productivity": { "keywords": ["포모도로", "집중", "할 일", "타이머"] },
    "commerce":     { "keywords": ["쇼핑", "결제", "재고", "주문"] },
    "health":       { "keywords": ["운동", "건강", "식단", "걸음"] },
    "finance":      { "keywords": ["가계부", "예산", "투자", "환율"] },
    "generic":      { "keywords": [] }
  }
  ```
- 도메인별 질문/템플릿:
  - 질문: `SpecAgent/questions_<domain>_ko.json`
  - 템플릿: `SpecTemplates-<domain>/`
  - 매핑(선택): `SpecTemplates-<domain>/mapping.json`

## 감지 절차
1. 아이디어 문자열 토큰화 → 키워드 매칭 → 점수 산출.
2. 점수 상위 1개가 임계(0.6) 이상이면 자동 선택.
3. 낮은 확신(0.6 미만) 또는 복수 도메인 근접 시:
   - 추천 도메인 목록과 이유를 사용자에게 제시.
   - 사용자가 하나를 고르거나 “기타” 선택 시 `generic` 사용.
4. 필요시 LLM 보조:
   - “다음 후보 중 가장 적합한 도메인을 고르라” 프롬프트 제공.
   - 출력은 도메인 이름 + 확신도 형태.

## 도메인 없음/새 도메인 추가
- 감지 실패 시 `generic` 질문/템플릿 사용.
- 새 도메인 추가 절차:
  1. `domain_catalog.json`에 키워드 등록.
  2. 질문 JSON 복제 후 도메인 맞춤 질문 작성.
  3. 템플릿 복제(AIPRD/TRD/TESTS/TASKS/CODEX) 후 자리표시자 수정.
  4. `mapping.json` 업데이트(answers 키 ↔ 템플릿 필드).
  5. `generate_specs.py`가 `--templates SpecTemplates-<domain>` 옵션을 수용하도록 호출.

## 실행 시퀀스 예시
```bash
# 1) 도메인 감지
python SpecAgent/domain_classifier.py --idea "새벽에 운동하고 식단 기록하는 앱" --catalog SpecAgent/domain_catalog.json
# ⇒ {"domain": "health", "confidence": 0.87}

# 2) 인터뷰
python SpecAgent/cli.py --questions SpecAgent/questions_health_ko.json --output SpecAgent/output/health

# 3) 명세 생성
python scripts/generate_specs.py --answers SpecAgent/output/health/answers_ko.json --templates SpecTemplates-health --lang ko
```

