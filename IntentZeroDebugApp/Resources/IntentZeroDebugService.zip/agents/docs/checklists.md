# 단계별 체크리스트 & STOP 조건

## 인터뷰 단계
- [ ] 도메인 자동 감지 → 확신도 ≥ 0.6 (미만 시 사용자 확인)
- [ ] 목표 한 줄, NSM(숫자), OUT ≥ 3개
- [ ] Jobs 3개(When/I want/So I can)
- [ ] 범위(기간, 화면 수, 저장 방식) 명시
- [ ] 임계/오차/정렬/주차 규칙 수치화
- [ ] 테스트 가속값(FOCUS/BREAK) 수집
- [ ] 접근성 ID 목록 확보
- [ ] 상황별 카피(시작/미기록/완료/알림 거부)
- STOP & ASK: 필수 답변이 비었거나 “미정” 반복 → 사용자와 추가 인터뷰 필요

## 명세 생성 단계
- [ ] `generate_specs.py` 실행 완료
- [ ] GeneratedSpecs-<domain>/* 문서에 `TODO(` 없음
- [ ] `spec_summary.md` 작성 완료
- STOP & ASK: 자리표시자 미채움 발견 → 인터뷰 단계로 되돌려 누락 질문 확인

## 코딩 단계
- [ ] StackPlan(120~180 토큰) 승인
- [ ] TASKS 순서대로 구현 (UI-TABS → … → TESTS)
- [ ] TRD 규칙(폴더 의존, 시간/정렬/임계, a11y) 준수
- [ ] 테스트 명령 실행 (build/test 로그 생성)
- [ ] S0~S8 체크박스 모두 통과
- [ ] reports/test.log 성공, 실패 시 summary.txt 작성 후 재시도
- STOP & ASK: OUT 기능 요구, 외부 의존 필요, 명세 충돌, StackPlan 비승인, 테스트 환경 부재

## 릴리즈/보고
- [ ] Progress Dashboard 업데이트 (현재 단계·테스트 상태)
- [ ] 완료 요약(목표 달성, NSM 기대치, 남은 TODO=0) 보고
- [ ] 사용자 피드백 수집 및 다음 라운드 질문 준비

