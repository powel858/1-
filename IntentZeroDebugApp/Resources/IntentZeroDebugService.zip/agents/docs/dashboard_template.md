# 진행 상황 대시보드 템플릿

목표: 사용자에게 현재 개발 단계, 다음 단계, 테스트 상태를 직관적으로 보여주어 “의도 집중” 경험을 유지한다.

## 구조 예시 (Markdown / 노션 보드)

### 1. 프로젝트 스냅샷
- 한 줄 목표: _(AIPRD.goal.one_liner)_
- NSM: _(AIPRD.goal.nsm)_
- 현재 단계: _(TASKS에서 In Progress 항목)_
- 다음 단계: _(TASKS에서 Pending → 가장 우선 항목)_
- 최근 업데이트: _(날짜/시간)_

### 2. 작업 칸반
| 상태         | TASKS ID | 설명 | 완료 조건(DoD) | 참고 문서 |
|--------------|----------|------|----------------|-----------|
| To Do        | WEEK-STATS | 주간 합계 + Top1 | HH:MM 합계, Top1 1개, 시작일 귀속 | GeneratedSpecs/TASKS.md |
| In Progress  | CORE-TIMER | 타이머 엔진 | 감소 가시성, ±1초, pause/resume 정확성 | GeneratedSpecs/TRD.md |
| Done         | UI-TABS | 탭 프레임 | TabView 3탭, ScenePhase 훅 | GeneratedSpecs/TASKS.md |

### 3. 테스트 체크리스트 (TESTS.md, S0~S8)
- [ ] S0 타이머 감소 가시성
- [ ] S1 ≥ 임계(예: 60초)만 기록
- [ ] S2 휴식 세션 미기록
- [ ] S3 시작일 귀속(일→월)
- [ ] S4 주간 HH:MM + Top1 1개
- [ ] S5 카테고리 정렬 & 상단 3칩
- [ ] S6 일시정지/재개 ±1초
- [ ] S7 백그라운드/복귀 자동 동기화
- [ ] S8 알림 거부 내성
- 가속 env: `FOCUS_SEC_FOR_TEST=10`, `BREAK_SEC_FOR_TEST=3`

### 4. 보고 & 로그
- Build log: `reports/build.log`
- Test log: `reports/test.log`
- 실패 요약: `reports/summary.txt` (필요 시)
- Spec 요약: `GeneratedSpecs-<domain>/spec_summary.md`

### 5. 리스크 & 차단 이슈
- 차단 사유, 요청 도움, 해결 기한을 기록

## 운영 팁
- StackPlan 승인 시점, 테스트 통과 시점을 타임라인으로 표시하면 사용자 신뢰가 높아진다.
- TODO/STOP 조건 발생 시 빨간색 태그로 표시하고, “사용자 확인 필요” 섹션에 링크한다.
- 노션/피그잼/타스크 관리 툴에 동일한 템플릿을 적용하면 협업이 쉬워진다.

