# Intent Zero-Debug Service (Single Package)

이 패키지는 사용자 아이디어를 인터뷰하고, 명세서 5종을 생성하며, iOS 앱을 무디버깅으로 구현/테스트하는 전 과정을 단일 ZIP으로 제공합니다. 추가 리포나 설정 없이, 여기에 포함된 자료만으로 서비스를 실행할 수 있습니다.

## 폴더 구성
```
IntentZeroDebugService/
├─ README.md                      # 전체 사용 가이드
├─ agents/
│  ├─ commands/                   # LLM/에이전트에게 전달할 명령 프롬프트 3종
│  └─ docs/                       # 서비스 블루프린트·대시보드·체크리스트
├─ SpecAgent/
│  ├─ cli.py                      # 인터뷰 CLI
│  ├─ domain_classifier.py        # 아이디어 → 도메인 감지 스크립트
│  ├─ domain_catalog.json         # 도메인 키워드 사전
│  ├─ questions_generic_ko.json   # 기본 질문 세트(R0~R3)
│  └─ questions_productivity_ko.json # 생산성(포모도로 등) 추가 질문 세트
├─ SpecTemplates-ko/              # 명세서 5종 템플릿(AIPRD/TRD/TESTS/TASKS/CODEX)
├─ scripts/
│  └─ generate_specs.py           # answers JSON → 명세서 5종 변환 스크립트
└─ examples/
   └─ walkthrough.md              # 실행 예제 및 명령 흐름
```

## 빠른 시작
1. **도메인 감지**
   ```bash
   python SpecAgent/domain_classifier.py --idea "만들고 싶은 서비스 한 줄" --catalog SpecAgent/domain_catalog.json
   ```
   - 출력: `{ "domain": "productivity", "confidence": 0.82 }`
   - 확신도 < 0.6 또는 복수 후보 시 사용자에게 다시 확인.

2. **사용자 인터뷰**
   ```bash
   python SpecAgent/cli.py --lang ko --questions SpecAgent/questions_<domain>_ko.json --output output/<domain>
   ```
   - 라운드별 질문(R0~R3)으로 answers JSON 수집.

3. **명세서 생성**
   ```bash
   python scripts/generate_specs.py --answers output/<domain>/answers_ko.json --lang ko --templates SpecTemplates-ko
   ```
   - 생성물: `GeneratedSpecs-ko/` 폴더와 ZIP (AIPRD/TRD/TESTS/TASKS/CODEX).

4. **코딩 에이전트 실행**
   - `agents/commands/3_coding_agent.prompt`를 LLM/자동화 시스템에 전달.
   - StackPlan → TASKS 순서 → 빌드/테스트 → reports 로그 출력.

5. **대시보드/체크리스트**
   - `agents/docs/dashboard_template.md`, `agents/docs/checklists.md` 활용.

## 요구 사항
- Python 3.x (인터뷰/명세 생성 스크립트)
- macOS + Xcode(Command Line Tools) + iOS 시뮬레이터 (코딩/빌드/테스트 단계)
- 테스트 가속 ENV: `FOCUS_SEC_FOR_TEST=10`, `BREAK_SEC_FOR_TEST=3`

## 확장
- 새 도메인을 추가하려면 `SpecAgent/domain_catalog.json`, `questions_<domain>_ko.json`, `SpecTemplates-<domain>/`를 복제/수정하세요.
- LLM/에이전트 자동화를 위해 `agents/commands/*.prompt`를 그대로 복사해 사용하면 됩니다.
