# 실행 예시 워크플로우

## 1) 도메인 감지
```bash
python SpecAgent/domain_classifier.py --idea "포모도로 타이머로 매일 집중 기록을 관리하고 싶어요" --catalog SpecAgent/domain_catalog.json
```
예시 출력:
```json
{
  "idea": "포모도로 타이머로 매일 집중 기록을 관리하고 싶어요",
  "domain": "productivity",
  "confidence": 0.71,
  "scores": {
    "productivity": 1.693,
    "commerce": 0.0,
    "health": 0.0,
    "finance": 0.0,
    "generic": 0.0
  },
  "hint": "Use this domain if confidence ≥ 0.6; otherwise ask the user."
}
```

## 2) 인터뷰 실행
```bash
python SpecAgent/cli.py --lang ko --questions SpecAgent/questions_productivity_ko.json --output output/productivity
```
- R0~R3 질문에 답하면 `output/productivity/answers_ko.json` 생성

## 3) 명세서 생성
```bash
python scripts/generate_specs.py --answers output/productivity/answers_ko.json --lang ko --templates SpecTemplates-ko
```
- `GeneratedSpecs-ko/`에 AIPRD/TRD/TESTS/TASKS/CODEX와 ZIP 생성

## 4) 코딩 에이전트 지침 사용
- `agents/commands/3_coding_agent.prompt`을 LLM에 전달
- StackPlan → 구현 → 테스트 → `reports/` 로그 생성

## 5) 진행 상황 시각화
- `agents/docs/dashboard_template.md`를 노션/피그잼 등에 붙여서 현재 단계 표시
- `agents/docs/checklists.md`로 해야 할 일/STOP 조건 확인
