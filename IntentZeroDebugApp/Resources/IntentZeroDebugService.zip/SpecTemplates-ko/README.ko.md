# SpecTemplates-ko — 사용 안내

- 각 템플릿의 {{...}} 자리표시자를 프로젝트 컨텍스트로 채워 주세요. 사용자의 의도가 1순위이며, 스택/버전은 에이전트가 최적값으로 처리합니다.
- 비어 있는 항목은 SpecTemplates-ko/QUESTIONS.ko.md 질문 목록으로 신속히 파악해 보완하세요.

## 파일 구성
- AIPRD.template.ko.md — 제품 의도 템플릿
- TRD.template.ko.md — 기술 가드레일(에이전트 자율) 템플릿
- TESTS.template.ko.md — 수용 기준/시나리오 템플릿
- TASKS.template.ko.md — 작업 그래프/DOD 템플릿
- CODEX.template.ko.md — 실행 계약/빌드·테스트 템플릿
- QUESTIONS.ko.md — 빈 컨텍스트를 채우기 위한 질문 모음

## 작성 팁
- 도구 버전 고정보다 결과/흐름/제약을 명확히 하세요.
- 모호성 줄이기: 임계값/반올림/정렬·동률 규칙을 구체화하세요.
- 범위 관리: OUT 항목을 명시적으로 기록하세요.
