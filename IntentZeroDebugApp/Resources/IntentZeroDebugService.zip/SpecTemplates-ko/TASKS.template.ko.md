# TASKS — 작업 그래프 템플릿

tasks:
  - id: STACK-PLAN
    name: 스택/구조 선택(에이전트)
    depends_on: []
    outputs:
      - "StackPlan(120~180 tokens): UI/state/persistence/notifications/testing"
      - "파일맵 개요(≤{{file_limit}} files / {{dir_limit}} dirs)"
      - "S0–S8 통과 근거"
    policy:
      - "OUT 위반 또는 외부 의존 필요 시 STOP & ASK"

  - id: UI-TABS
    name: 탭/내비게이션 뼈대(타이머/기록/통계)
    depends_on: [STACK-PLAN]
    outputs: [ "탭 구조/화면 전환/기본 레이아웃" ]
    dod:
      - "3탭 라벨/아이콘"
      - "scenePhase 훅으로 background/active 처리"

  - id: CORE-TIMER
    name: 동작 엔진 + 상태머신 + 감소 표시
    depends_on: [UI-TABS]
    outputs: [ "idle/running/paused/finished", "감소 표시", "가속 env" ]
    dod:
      - "매초 감소(±{{tolerance_sec}}초)"
      - "일시정지/재개 누적 정확성"
      - "{{focus_env_key}}/{{break_env_key}} 적용"

  - id: LIFECYCLE-NOTI
    name: 백그라운드/복귀 동기화 + 알림 내성
    depends_on: [CORE-TIMER]
    outputs: [ "scenePhase 동기화", "알림 예약/취소", "거부 폴백" ]
    dod:
      - "백그라운드 시 예약"
      - "액티브 복귀 시 refresh"
      - "거부/에러 시 폴백 문구"

  - id: RECORD-MIN1
    name: ≥ 임계 기록 + 메모/카테고리
    depends_on: [CORE-TIMER]
    outputs: [ "기록 생성", "미기록 안내", "lastUsed 갱신" ]
    dod:
      - ">={{min_record_secs}}초만 기록"
      - "휴식 세션은 기록 제외"
      - "메모/카테고리 저장"

  - id: CATEGORY-UX
    name: 최근 사용 우선(+상단 3칩) & 카테고리 추가
    depends_on: [RECORD-MIN1]
    outputs: [ "정렬 규칙", "퀵칩", "+추가" ]
    dod:
      - "정렬: {{category_sort_rule}}"
      - "상단 3칩"
      - "신규 카테고리 now 타임스탬프"

  - id: WEEK-STATS
    name: 시작일 귀속 + 주간 통계(HH:MM + Top1)
    depends_on: [RECORD-MIN1]
    outputs: [ "주간 합계", "Top1", "월요일 시작" ]
    dod:
      - "HH:MM 합계"
      - "Top1 1개(동률 규칙)"
      - "시작일 귀속"

  - id: ACCESSIBILITY-IDS
    name: 테스트 식별자 중앙화
    depends_on: [UI-TABS]
    outputs: [ "AccessibilityIDs.swift", "UI 테스트 안정성" ]
    dod:
      - "필수 ID 적용: {{accessibility_ids_list}}"

  - id: TESTS
    name: S0–S8 시나리오(가속 포함)
    depends_on: [CORE-TIMER, LIFECYCLE-NOTI, RECORD-MIN1, CATEGORY-UX, WEEK-STATS, ACCESSIBILITY-IDS]
    outputs: [ "유닛/UX 로그", "(선택) 스크린샷", "요약 리포트" ]
    dod:
      - "가속 env 필수 또는 Skip 사유 명시"
      - "디바이스 대체 허용"
      - "reports/* 및 summary.txt 산출"
