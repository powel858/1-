# TESTS — 수용 기준 & 시나리오 템플릿

## 수용 기준(모두 통과)
1) S0 감소 가시성: 레이블이 실제로 감소(±{{tolerance_sec}}초)
2) 기록 임계치: ≥ {{min_record_secs}}초일 때만 기록 생성
3) 경계 집계: {{boundary_rule}}(시작일 기준)
4) 주간 통계: {{weekly_rule}} (HH:MM 합계 + Top1 1개)
5) 카테고리 선택: {{category_sort_rule}} + 상단 3칩
6) 일시정지/재개 정확성: ±{{tolerance_sec}}초
7) 백그라운드/복귀 정확성: 종료 기반 동기화; 필요 시 자동 완료
8) 알림 거부 내성: 크래시 없음; 폴백 문구 노출

## 테스트 전제
- 가속 env: {{focus_env_key}}={{focus_env_value}}, {{break_env_key}}={{break_env_value}}
- 대상 디바이스: {{device_rule}}
- 로케일/캘린더: {{locale_calendar_rule}}

## Gherkin (예시)
### S0. 타이머 감소 가시성
Given 타이머 화면을 연다
When 시작하고 {{wait_secs}}초 기다린다
Then 남은 시간 레이블이 감소한다 (±{{tolerance_sec}}초)

### S1. 최소 기록 임계치
Given 타이머 실행 중
When {{stop_secs}}초에 종료한다
Then 기록이 생성되지 않는다

### S3. 주간 경계(시작일 귀속)
Given {{boundary_start_desc}}에 시작하고 {{boundary_end_desc}}에 종료한다
When 기록이 생성된다
Then 세션은 시작한 날/주로 집계된다

## 로그 & 증거
- 빌드/테스트 로그를 {{reports_dir}}에 저장
- 실패 시 요약 포함: root cause / evidence / fix plan
