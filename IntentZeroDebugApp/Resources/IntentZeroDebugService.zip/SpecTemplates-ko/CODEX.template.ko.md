# CODEX — 실행 계약 템플릿

## 1) StackPlan Gate(먼저 산출)
- StackPlan(120~180 tokens): UI/state/persistence/notifications/testing(로컬 우선; 외부 의존 금지), 파일맵(≤{{file_limit}} files / {{dir_limit}} dirs), S0–S8 근거.
- OUT 위반/의존 필요 시 STOP & ASK.

## 2) 구현
- 프로젝트 "{{project_name}}" 생성 및 파일맵에 따라 생성.
- 타이머: 가시적 감소; 일시정지/재개; 백그라운드/복귀 동기화.
- 기록: duration ≥ {{min_record_secs}}초만 생성; 월요일 주 시작; 시작일 귀속.
- 통계: HH:MM 합계 + Top1 1개.
- 카테고리: {{category_sort_rule}}; 상단 3칩.
- 테스트 가속: env(예: {{focus_env_key}}={{focus_env_value}}, {{break_env_key}}={{break_env_value}}).

스캐폴딩 체크리스트(MUST)
- 개발 자산 경로 존재 확인(예: Preview Content).
- TRD의 접근성 ID 적용.

## 3) 빌드 & 테스트
```bash
mkdir -p reports
xcodebuild -list > reports/targets.txt
xcodebuild -scheme {{project_name}} -destination 'platform=iOS Simulator,name={{primary_simulator}}' build | tee reports/build.log
{{focus_env_key}}={{focus_env_value}} {{break_env_key}}={{break_env_value}} xcodebuild -scheme {{project_name}} -destination 'platform=iOS Simulator,name={{primary_simulator}}' test | tee reports/test.log
```
셸/권한이 없으면 동일 커맨드를 사용자에게 출력.

Destination Fallback
```bash
xcodebuild -scheme {{project_name}} -destination 'platform=iOS Simulator,name={{fallback_simulator}}' build
{{focus_env_key}}={{focus_env_value}} {{break_env_key}}={{break_env_value}} xcodebuild -scheme {{project_name}} -destination 'platform=iOS Simulator,name={{fallback_simulator}}' test
```

## 4) Pass/Fail
- S0–S8 통과 후 종료. 1회 최소 수정 사이클 허용; 실패 시 `./reports/summary.txt` 작성.

`reports/summary.txt` 템플릿:
- Root cause:
- Evidence (log/path):
- Fix plan (1–2 lines):

## 5) Output 규칙
- 산출물 + 최소 `reports/summary.txt`만. 장문 설명 금지.
- no_invention_policy: true — 정보 부족 시 질문.
