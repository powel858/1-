# AIPRD — 제품 의도 템플릿

## North Star
- 향상하고 싶은 1차 지표: {{north_star_metric}} (예: {{weekly_consecutive_use_ratio}})

## Appetite (시간 상자)
- 라운드 시간: {{timebox_hours}}시간
- 품질 기준/메모: {{quality_notes}}

## Jobs (사용자 의도)
1) When {{job1_when}}, I want to {{job1_want}}, so I can {{job1_why}}.
2) When {{job2_when}}, I want to {{job2_want}}, so I can {{job2_why}}.
3) When {{job3_when}}, I want to {{job3_want}}, so I can {{job3_why}}.

## Scope (이번 라운드)
- 포함(IN): {{in_scope_items}}
- 제외(OUT): {{out_scope_items}}

## Journey (탭/흐름)
- 진입 → {{primary_flow}} → {{secondary_flow}} → {{outcome_view}}

## Tone & Copy
- 시작: {{copy_start}}
- 60초 미만 중단: {{copy_under_minute}}
- 완료: {{copy_complete}}
- 알림 거부: {{copy_notify_denied}}

## Guardrails
- no_invention_policy: true
- must_ask_before_build: [{{ask_gates}}]

## 용어/명확화
- 기록 가능(Recordable): {{recordable_rule}}
- 시작일 귀속: {{start_day_rule}}
- 세션 타입: {{session_types}}
- 시간/달력/로캘: {{time_rules}}

## Handoff Notes
- 구현 세부(반올림/정렬/a11y ID/테스트 가속)는 TRD에 집중 기술. 본 문서는 의도/범위를 간결히 유지.
