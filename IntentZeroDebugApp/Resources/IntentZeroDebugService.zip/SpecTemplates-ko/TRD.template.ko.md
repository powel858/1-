# TRD — 기술 요구 & 가드레일 템플릿

> 에이전트는 스택/구조를 자율 선택한다. 가드레일은 준수. UI-only는 실패.

## 에이전트 자율(스택)
- 사용자 문서에 도구 버전을 노출하지 않는다.
- 에이전트는 합리적 기본값을 선택하고 S0–S8 충족/무에러 실행을 보장한다.
- 주차/시간 의미는 일관성 유지(예: ISO 주 + 월요일 시작).

## 안티-스파게티 아키텍처(MUST)
- 폴더: `/Features`, `/Data`, `/Services`, `/Design`, `/Tests`
- 의존: `Features → (Services, Data, Design)`, `Services → Data`, `Data`는 어떤 것도 import하지 않음
- 양방향 의존 금지; UI→Data 직접 접근 금지
- 파일 크기 ≤ {{max_lines_per_file}}라인; 타입 단일 책임
- `Design/AccessibilityIDs.swift`: 테스트 식별자 중앙화
- `Services/DateProvider`(또는 동등): 주입 가능한 시간 소스

## 프로젝트 스캐폴딩(MUST)
- 프로젝트가 선언한 개발 자산 경로(예: `Preview Content`)가 실제로 존재해야 함.

## 도메인 규칙
- 타이머 상태: `idle | running | paused | finished`
- 세션 타입: {{session_types_rule}}
- 기록 생성: {{record_creation_rule}}
- 시작일 귀속: {{start_day_rule}}
- 주차 기준: {{week_baseline_rule}}
- 카테고리 정렬: {{category_sort_rule}}

## 개념 데이터
- `Category { id, name, lastUsedAt, createdAt }`
- `Session { id, startAt, endAt, durationSec, note, categoryId? }`
- 파생: `weekOf(startAt, mondayStart={{monday_start_bool}})` / `isRecordable = (durationSec {{recordable_operator}} {{recordable_threshold_sec}})`

## 시간 & 반올림 규칙
- 남은 시간은 초 단위로 표시; 허용 오차 ±{{timing_tolerance_sec}}초
- 일시정지/재개 정확도: 활성 구간 누적 합산으로 보정

## 영속성 프레디케이트 규칙(MUST)
- 선택한 저장소/ORM 제약에 맞게 작성. enum 직접 비교가 불가하면 rawValue 등 안정 값으로 비교.

## 타깃 파일 맵(≤ {{file_limit}} files / {{dir_limit}} dirs)
- {{file_map_outline}}

## 타이머 & 라이프사이클(MUST)
- 시작: 목표 종료 또는 잔여 설정; UI는 가시적으로 감소(≤1Hz)
- 일시정지/재개: 잔여 저장/복원; 알림 사용 시 예약/취소
- 완료: duration 계산; 기록 가능 조건일 때만 생성; 알림 취소
- 백그라운드/복귀: 종료 알림 예약; 복귀 시 시간차로 상태 동기화 및 필요 시 자동 완료

## 접근성 ID
- 필수: {{accessibility_ids_list}}

## 테스트 시간 단축(MUST)
- env 플래그 제공(예: {{focus_env_key}}/{{break_env_key}}) 또는 동등 입력으로 테스트용 단축
- 미제공 시 실패 또는 Skip 사유 명시

## 통계
- 주간(월~일); 총 HH:MM; Top1 1개만; 동률은 결정적 규칙(예: 최근 사용→최근 생성→이름)

## 품질 기준
- 빌드 에러 0; 경고 최소; 시간 정확도 ±{{timing_tolerance_sec}}초 이내
- UI-only 구현은 S0에서 실패

## 비협상
- no_invention_policy: true
- OUT 기능 금지(명시 승인 없으면); 게이트 조건에서 질문
