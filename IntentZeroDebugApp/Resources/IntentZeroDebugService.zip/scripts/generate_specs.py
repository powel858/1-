#!/usr/bin/env python3
"""Render spec templates (en/ko) using collected answers."""

import argparse
import json
import os
import re
import zipfile
from pathlib import Path

PLACEHOLDER_RE = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


def fill_content(content: str, mapping: dict, missing_marker: str = "TODO") -> str:
    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        if key in mapping and mapping[key] is not None:
            return str(mapping[key])
        return f"{missing_marker}({key})"

    return PLACEHOLDER_RE.sub(repl, content)


def collect_mapping(answers: dict) -> dict:
    flat: dict = {}

    def walk(prefix: str, obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                walk(f"{prefix}_{k}" if prefix else k, v)
        else:
            flat[prefix] = obj

    walk("", answers)

    # Add common alias keys so templates with older placeholder names still fill.
    # These aliases are non-destructive: only applied when the canonical key exists
    # and the alias key is missing.
    aliases = {
        # TESTS/CODEX older placeholders → TRD canonical keys
        "tolerance_sec": "timing_tolerance_sec",
        "min_record_secs": "recordable_threshold_sec",
    }
    for alias, canonical in aliases.items():
        if alias not in flat and canonical in flat:
            flat[alias] = flat[canonical]

    return flat


def render_dir(template_dir: Path, out_dir: Path, mapping: dict, missing_marker: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    for src in sorted(template_dir.glob("*.md")):
        with src.open("r", encoding="utf-8") as fh:
            content = fh.read()
        filled = fill_content(content, mapping, missing_marker)
        target_name = src.name.replace(".template", "")
        with (out_dir / target_name).open("w", encoding="utf-8") as fh:
            fh.write(filled)


def package_dir(base: Path, out_dir: Path) -> Path:
    zip_path = base / f"{out_dir.name}.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(out_dir):
            for name in files:
                file_path = Path(root) / name
                arcname = file_path.relative_to(base)
                zf.write(file_path, arcname=str(arcname))
    return zip_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Render spec templates from answers JSON")
    parser.add_argument("--answers", required=True, help="Path to answers JSON file")
    parser.add_argument("--lang", choices=["en", "ko"], default="en")
    parser.add_argument("--missing", default="TODO", help="Marker for missing placeholders")
    args = parser.parse_args()

    answers_path = Path(args.answers).expanduser().resolve()
    if not answers_path.exists():
        raise SystemExit(f"Answers file not found: {answers_path}")

    with answers_path.open("r", encoding="utf-8") as fh:
        answers = json.load(fh)

    mapping = collect_mapping(answers)

    base = Path.cwd()
    template_dir = base / ("SpecTemplates" if args.lang == "en" else "SpecTemplates-ko")
    if not template_dir.exists():
        raise SystemExit(f"Template directory not found: {template_dir}")

    out_dir = base / ("GeneratedSpecs-en" if args.lang == "en" else "GeneratedSpecs-ko")
    render_dir(template_dir, out_dir, mapping, args.missing)
    zip_path = package_dir(base, out_dir)

    print(f"Rendered templates → {out_dir}")
    print(f"Packaged zip → {zip_path}")


if __name__ == "__main__":
    main()
