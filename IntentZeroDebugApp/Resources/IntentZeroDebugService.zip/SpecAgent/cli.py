#!/usr/bin/env python3
"""Interactive CLI to collect answers and render development spec packages."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict


INT_KEYS = {
    "timebox_hours",
    "recordable_threshold_sec",
    "timing_tolerance_sec",
    "file_limit",
    "dir_limit",
    "focus_env_value",
    "break_env_value",
    "wait_secs",
    "stop_secs",
}

BOOL_KEYS = {"monday_start_bool"}


def repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def questions_path(lang: str) -> Path:
    name = f"questions_{lang}.json"
    return Path(__file__).resolve().parent / name


def load_questions(lang: str, override_path: str | None = None) -> Dict[str, Any]:
    q_path = Path(override_path).resolve() if override_path else questions_path(lang)
    if not q_path.exists():
        sys.exit(f"Question file not found: {q_path}")
    with q_path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def prompt_value(prompt: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default not in (None, "") else ""
    value = input(f"{prompt}{suffix}: ").strip()
    if not value:
        return default or ""
    return value


def normalize_value(key: str, value: str) -> Any:
    if key in BOOL_KEYS:
        lowered = value.lower()
        if lowered in {"true", "t", "yes", "y", "1", "예", "네"}:
            return True
        if lowered in {"false", "f", "no", "n", "0", "아니오"}:
            return False
        return value  # leave as-is if ambiguous
    if key in INT_KEYS:
        try:
            return int(value)
        except ValueError:
            return value
    if value.lower() == "null":
        return None
    return value


def collect_answers(lang: str, override_path: str | None = None) -> Dict[str, Any]:
    questions = load_questions(lang, override_path)
    answers: Dict[str, Any] = {}
    print("\n=== Development Spec Interview ===")
    for group in questions.get("groups", []):
        title = group.get("title")
        if title:
            print(f"\n[{title}]")
        for item in group.get("questions", []):
            key = item["key"]
            prompt = item.get("prompt", key)
            default = item.get("default")
            value = prompt_value(prompt, default)
            answers[key] = normalize_value(key, value)
    return answers


def write_answers(lang: str, answers: Dict[str, Any], output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    answers_path = output_dir / f"answers_{lang}.json"
    with answers_path.open("w", encoding="utf-8") as fh:
        json.dump(answers, fh, ensure_ascii=False, indent=2)
    return answers_path


def run_generator(lang: str, answers_path: Path) -> None:
    generator = repo_root() / "scripts" / "generate_specs.py"
    if not generator.exists():
        sys.exit(f"Generator script not found: {generator}")
    cmd = [sys.executable, str(generator), "--answers", str(answers_path), "--lang", lang]
    print("\nRunning generator:\n", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Interactive developer spec authoring agent")
    parser.add_argument("--lang", choices=["en", "ko"], default="ko", help="Interview language (default: ko)")
    parser.add_argument(
        "--questions",
        default=None,
        help="Optional path to a questions JSON file (overrides --lang default)",
    )
    parser.add_argument(
        "--output",
        default=str(repo_root() / "SpecAgent" / "output"),
        help="Directory to store collected answers (default: SpecAgent/output)",
    )
    args = parser.parse_args()

    answers = collect_answers(args.lang, args.questions)
    output_dir = Path(args.output).resolve()
    answers_path = write_answers(args.lang, answers, output_dir)

    print("\nSaved answers to:", answers_path)

    choice = input("Generate spec bundle now? [y/N]: ").strip().lower()
    if choice in {"y", "yes", "예", "네"}:
        run_generator(args.lang, answers_path)
    else:
        print("Skipped generation. You can run the generator later:")
        print(
            f"  python scripts/generate_specs.py --answers {answers_path} --lang {args.lang}"
        )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
