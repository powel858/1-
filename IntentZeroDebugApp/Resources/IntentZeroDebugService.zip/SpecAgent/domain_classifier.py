#!/usr/bin/env python3
"""Simple keyword-based domain classifier for user ideas."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, List


def load_catalog(path: Path) -> Dict[str, Dict[str, List[str]]]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def score_idea(idea: str, keywords: List[str]) -> float:
    idea_lower = idea.lower()
    total = 0
    for word in keywords:
        word_lower = word.lower().strip()
        if not word_lower:
            continue
        count = idea_lower.count(word_lower)
        if count:
            total += 1 + math.log10(count + 1)
    return total


def classify(idea: str, catalog: Dict[str, Dict[str, List[str]]]) -> Dict[str, float]:
    scores: Dict[str, float] = {}
    for domain, meta in catalog.items():
        keywords = meta.get("keywords", [])
        scores[domain] = score_idea(idea, keywords)
    return scores


def main() -> None:
    parser = argparse.ArgumentParser(description="Detect best-fit domain for an idea")
    parser.add_argument("--idea", required=True, help="User idea in one sentence")
    parser.add_argument("--catalog", default="domain_catalog.json", help="Path to domain catalog JSON")
    args = parser.parse_args()

    catalog_path = Path(args.catalog).resolve()
    if not catalog_path.exists():
        raise SystemExit(f"Domain catalog not found: {catalog_path}")

    catalog = load_catalog(catalog_path)
    scores = classify(args.idea, catalog)
    best_domain = max(scores, key=scores.get)
    best_score = scores[best_domain]
    total = sum(scores.values())
    confidence = 0.0 if total == 0 else best_score / total

    payload = {
        "idea": args.idea,
        "domain": best_domain,
        "confidence": round(confidence, 3),
        "scores": scores,
        "hint": "Use this domain if confidence ≥ 0.6; otherwise ask the user."
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


+if __name__ == "__main__":
+    main()
